@extends('admin.layout.index')
@section('content')
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <meta name="csrf-token" content="{{ csrf_token()}}">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN THEME PANEL -->
    {{--<div class="theme-panel">
        <div class="toggler tooltips" data-container="body" data-placement="left" data-html="true" data-original-title="Click to open advance theme customizer panel">
            <i class="icon-settings"></i>
        </div>
        <div class="toggler-close">
            <i class="icon-close"></i>
        </div>
        <div class="theme-options">
            <div class="theme-option theme-colors clearfix">
                <span> THEME COLOR </span>
                <ul>
                    <li class="color-default current tooltips" data-style="default" data-container="body" data-original-title="Default"> </li>
                    <li class="color-grey tooltips" data-style="grey" data-container="body" data-original-title="Grey"> </li>
                    <li class="color-blue tooltips" data-style="blue" data-container="body" data-original-title="Blue"> </li>
                    <li class="color-dark tooltips" data-style="dark" data-container="body" data-original-title="Dark"> </li>
                    <li class="color-light tooltips" data-style="light" data-container="body" data-original-title="Light"> </li>
                </ul>
            </div>
            <div class="theme-option">
                <span> Layout </span>
                <select class="layout-option form-control input-small">
                    <option value="fluid" selected="selected">Fluid</option>
                    <option value="boxed">Boxed</option>
                </select>
            </div>
            <div class="theme-option">
                <span> Header </span>
                <select class="page-header-option form-control input-small">
                    <option value="fixed" selected="selected">Fixed</option>
                    <option value="default">Default</option>
                </select>
            </div>
            <div class="theme-option">
                <span> Top Dropdown</span>
                <select class="page-header-top-dropdown-style-option form-control input-small">
                    <option value="light" selected="selected">Light</option>
                    <option value="dark">Dark</option>
                </select>
            </div>
            <div class="theme-option">
                <span> Sidebar Mode</span>
                <select class="sidebar-option form-control input-small">
                    <option value="fixed">Fixed</option>
                    <option value="default" selected="selected">Default</option>
                </select>
            </div>
            <div class="theme-option">
                <span> Sidebar Style</span>
                <select class="sidebar-style-option form-control input-small">
                    <option value="default" selected="selected">Default</option>
                    <option value="compact">Compact</option>
                </select>
            </div>
            <div class="theme-option">
                <span> Sidebar Menu </span>
                <select class="sidebar-menu-option form-control input-small">
                    <option value="accordion" selected="selected">Accordion</option>
                    <option value="hover">Hover</option>
                </select>
            </div>
            <div class="theme-option">
                <span> Sidebar Position </span>
                <select class="sidebar-pos-option form-control input-small">
                    <option value="left" selected="selected">Left</option>
                    <option value="right">Right</option>
                </select>
            </div>
            <div class="theme-option">
                <span> Footer </span>
                <select class="page-footer-option form-control input-small">
                    <option value="fixed">Fixed</option>
                    <option value="default" selected="selected">Default</option>
                </select>
            </div>
        </div>
    </div>--}}
    <!-- END THEME PANEL -->
    {{--<h1 class="page-title"> {{''}}
        <small>blank page layout</small>
    </h1>--}}
    <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="">الصفحة الرئيسية</a>
                    {{--<i class="fa fa-angle-right"></i>--}}
                </li>
               {{-- <li>
                    <span></span>
                </li>--}}
            </ul>
            <div class="page-toolbar">
                <div id="dashboard-report-range" class="pull-right tooltips btn btn-fit-height green"
                     data-placement="top" data-original-title="Change dashboard date range"
                     data-date-format="yyyy/mm/dd">
                    <i class="icon-calendar"></i>&nbsp;
                    <span class="thin uppercase hidden-xs"></span>&nbsp;
                    <i class="fa fa-angle-down"></i>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-settings font-dark"></i>
                            <span class="caption-subject bold uppercase"> جلسات اليوم</span>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <div class="table-toolbar">
                            <div class="row">

                            </div>
                        </div>
                        <table class="table table-striped table-bordered table-hover table-checkable order-column"
                               id="sample_1">
                            <thead>
                            <tr>

                                <th> #</th>
                                <th> رقم ملف الدعوة</th>
                                <th> نوع الدعوة</th>
                                <th> الموكل</th>
                                <th> الخصم</th>
                                <th> جهة الدعوة</th>
                                <th> المحكمة</th>
                                <th> الجلسة</th>
                                <th> تاريخ</th>

                            </tr>
                            </thead>
                            <tbody id="session_td">
                            <?php  $i = 0; ?>

                            @foreach($user_sessions as $user_session)

                                <tr class="odd gradeX">

                                    <td> {!! ++$i !!} </td>
                                    <td>
                                        <a href="#"
                                           onclick="show_lawysuit('{{$user_session['file_id']}}')"> {{$user_session['file_no']}}</a>
                                    </td>

                                    <td>
                                        <?php
                                        $bgColor = $user_session['file_color'];
                                        /*  if ($user_reminder->reminder_type == 3)
                                              $bgColor = "#1bbc9b";//green
                                          else if ($user_reminder->reminder_type == 4)
                                              $bgColor = "#F8CB00";//yellow*/

                                        ?>
                                        <span class="label label-sm "
                                              style="font-size: medium;background-color:{{$bgColor}}">  {{$user_session['type_desc']}} </span>
                                    </td>
                                    <td>
                                        {{$user_session['agent_name']}}
                                    </td>
                                    <td>
                                        {{$user_session['respondent_name']}}
                                    </td>
                                    <td>
                                        {{$user_session['judge']}}
                                    </td>
                                    <td>
                                        {{$user_session['court_name']}}
                                    </td>
                                    <td>
                                        {{$user_session['session_text']}}
                                    </td>

                                    <td>
                                        {{$user_session['session_date']}}
                                    </td>

                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-settings font-dark"></i>
                            <span class="caption-subject bold uppercase"> التنبيهات</span>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <div class="table-toolbar">
                            <div class="row">

                            </div>
                        </div>
                        <table class="table table-striped table-bordered table-hover table-checkable order-column"
                               id="sample_1">
                            <thead>
                            <tr>

                                <th> #</th>
                                <th> النص</th>
                                <th> الموظف</th>
                                <th> نوع التنبية</th>
                                <th> رقم الملف</th>
                                <th> نوع الدعوة</th>

                            </tr>
                            </thead>
                            <tbody id="reminder_td">
                            <?php  $i = 0; ?>
                            @foreach($user_reminders as $user_reminder)
                                <tr class="odd gradeX">

                                    <td> {!! ++$i !!} </td>
                                    <td>
                                        <a data-toggle="modal" href="#reminderModal"
                                           onclick="show_Reminder('{{$user_reminder->id}}')"> {{$user_reminder->event_text}}</a>
                                    </td>
                                    <td>
                                        {{$user_reminder->emp_name}}
                                    </td>
                                    <td>
                                        <?php if ($user_reminder->reminder_type == 1)
                                            echo '<span class="bg-font-red btn bg-red">' . $user_reminder->reminder_desc . '</span>';
                                        else if ($user_reminder->reminder_type == 2)
                                            echo '<span class="bg-font-red btn bg-blue">' . $user_reminder->reminder_desc . '</span>';
                                        else if ($user_reminder->reminder_type == 3)
                                            echo '<span class="bg-font-red btn bg-green">' . $user_reminder->reminder_desc . '</span>';
                                        else if ($user_reminder->reminder_type == 4)
                                            echo '<span class="bg-font-red btn bg-yellow">' . $user_reminder->reminder_desc . '</span>';?>


                                    </td>
                                    <td>
                                        <a href="#"
                                           onclick="show_lawysuit('{{$user_reminder->file_id}}')"> {{$user_reminder->file_no}}</a>
                                    </td>
                                    @if($user_reminder->file_desc!=='')
                                        <td>
                                            <?php
                                            $bgColor = $user_reminder->file_color;

                                            ?>
                                            <span class="label label-sm "
                                                  style="font-size: medium;background-color:{{$bgColor}}">  {{$user_reminder->file_desc}} </span>
                                        </td>
                                    @else
                                        <td></td>
                                    @endif
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-settings font-dark"></i>
                            <span class="caption-subject bold uppercase"> المهام</span>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <div class="table-toolbar">
                            <div class="row">

                            </div>
                        </div>
                        <table class="table table-striped table-bordered table-hover table-checkable order-column"
                               id="sample_1">
                            <thead>
                            <tr>

                                <th> #</th>
                                <th> المهمة</th>
                                <th> الموظف</th>
                                <th> الحالة</th>
                                <th> تحكم</th>
                            </tr>
                            </thead>
                            <tbody id="task_td">
                            <?php  $i = 0; ?>
                            @foreach($user_tasks as $user_task)
                                <tr class="odd gradeX">

                                    <td> {!! ++$i !!} </td>
                                    <td>
                                        <a data-toggle="modal" href="#taskModal"
                                           onclick="show_task('{{$user_task->task_desc}}','{{$user_task->task_date}}')"> {{$user_task->task_desc}}</a>
                                    </td>
                                    <td>
                                        {{$user_task->emp_name}}
                                    </td>
                                    <td>
                                        <?php
                                        $type = 'success';
                                        if ($user_task->task_status == 1)
                                            $type = 'success';
                                        else if ($user_task->task_status == 2)
                                            $type = 'info';
                                        else if ($user_task->task_status == 3)
                                            $type = 'warning';
                                        else if ($user_task->task_status == 4)
                                            $type = 'danger';
                                        ?>
                                        <span class="label label-sm label-{{$type}}"
                                              style="font-size: medium">  {{$user_task->status_name}} </span>
                                    </td>
                                    <td class="center"> {{$user_task->task_date}}</td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-xs purple-plum dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-expanded="false"> تحكم
                                                <i class="fa fa-angle-down"></i>
                                            </button>
                                            <ul class="dropdown-menu pull-left" role="menu">


                                                @foreach($task_statuses as $task_statuse)

                                                    <li>
                                                        <a href="javascript:;"
                                                           onclick="update_status({{$task_statuse->id}}{{','}}{{$user_task->id}})">
                                                            {{--  <i class="icon-docs"></i>--}}{{  $task_statuse->desc}}
                                                        </a>
                                                    </li>

                                                @endforeach
                                                {{-- <li>
                                                     <a href="javascript:;">
                                                         <i class="icon-docs"></i>  قيد العمل </a>
                                                 </li>
                                                 <li>
                                                     <a href="javascript:;">
                                                         <i class="icon-tag"></i>معلقة  </a>
                                                 </li>
                                                 <li>
                                                     <a href="javascript:;">
                                                         <i class="icon-user"></i>منتهية</a>
                                                 </li>
                                                 <li class="divider"> </li>
                                                 <li>
                                                     <a href="javascript:;">
                                                         <i class="icon-flag"></i> Comments
                                                         <span class="badge badge-success">4</span>
                                                     </a>
                                                 </li>--}}
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-settings font-dark"></i>
                            <span class="caption-subject bold uppercase"> الأرشيف الإداري</span>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <div class="table-toolbar">
                            <div class="row">

                            </div>
                        </div>
                        <table class="table table-striped table-bordered table-hover table-checkable order-column"
                               id="sample_1">
                            <thead>
                            <tr>

                                <th> #</th>
                                <th>اسم الملف</th>
                                <th>مكان الملف</th>
                                <th>نوع الملف</th>
                                <th>ملاحظات</th>
                                <th> الرابط</th>


                            </tr>
                            </thead>
                            <tbody id="arch_td">
                          {!! $user_archs !!}
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
        <div class="raw">
            <div class="portlet light ">
                <div class="portlet-title">
                    <div class="caption ">
                        <span class="caption-subject font-dark bold uppercase">الملفات القضائية</span>
                        <span class="caption-helper">انواع الملفات القضائية</span>
                    </div>
                    {{--<div class="actions">
                        <a href="#" class="btn btn-circle green btn-outline btn-sm">
                            <i class="fa fa-pencil"></i> Export </a>
                        <a href="#" class="btn btn-circle green btn-outline btn-sm">
                            <i class="fa fa-print"></i> Print </a>
                    </div>--}}
                </div>
                <div class="portlet-body">
                    <div id="dashboard_amchart_3" class="CSSAnimationChart"></div>
                </div>
            </div>
        </div>
        <!-- END PAGE HEADER-->

    </div>
    <div class="modal fade bs-modal-lg" id="taskModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"
                            aria-hidden="true"></button>
                    <h4 class="modal-title">عرض المهمة</h4>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN SAMPLE TABLE PORTLET-->

                            <div class="portlet box red-haze">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gift"></i>عرض المهمة
                                    </div>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse"> </a>

                                    </div>
                                </div>
                                <div class="portlet-body form">
                                    <!-- BEGIN FORM-->
                                    {{--  <form action="{{url('admin/user/'.$user_id)}}" class="form-horizontal" method="post">--}}
                                    {{Form::open(['url'=>"",'class'=>'form-horizontal','method'=>"post","id"=>"task_form"])}}

                                    <div class="form-body">


                                        <div class="form-group">
                                            <label class="control-label col-md-3">وقت وتاريخ المهمة
                                                <span class="required"> * </span></label>
                                            <div class="col-md-4">
                                                <div class="input-group date form_datetime" data-date=""
                                                     data-date-format="dd/mm/yyyy hh:mm:ss">
                                                    <input type="text" name="task_date" id="task_date" size="16"
                                                           readonly
                                                           value="" class="form-control" dir="ltr">
                                                    <span class="input-group-btn">

                                </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">المهمة
                                                <span class="required"> * </span></label>
                                            <div class="col-md-6">
                                                <div class="input-icon">
                                                    <i class="icon-book-open"></i>
                                                    <textarea class="form-control" name="task_desc" id="task_desc"
                                                              rows="3" disabled></textarea>
                                                </div>
                                            </div>
                                        </div>


                                    </div>

                                {{-- </form>--}}
                                {{Form::close()}}
                                <!-- END FORM-->
                                </div>
                            </div>
                            <!-- END SAMPLE TABLE PORTLET-->
                        </div>

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn dark btn-outline" data-dismiss="modal">اغلاق
                    </button>

                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade bs-modal-lg" id="reminderModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"
                            aria-hidden="true"></button>
                    <h4 class="modal-title">عرض التنبية</h4>
                </div>

                <div class="modal-body">
                    <div class="raw">

                        <div class="portlet box green">
                            <div class="portlet-title">
                                <div class="caption" id="fileDv">
                                    <i class="fa fa-gift"> </i>&nbsp;&nbsp;-&nbsp;رقم الملف&nbsp;(<label
                                        id="file_no"></label>)
                                </div>
                                <div class="tools">
                                    <a href="javascript:;" class="collapse"> </a>

                                </div>
                            </div>
                            <div class="portlet-body form">
                                <!-- BEGIN FORM-->
                                {{--  <form action="{{url('admin/user/'.$user_id)}}" class="form-horizontal" method="post">--}}
                                {{Form::open(['url'=>'','class'=>'form-horizontal','method'=>"post","id"=>"procedure_form"])}}

                                <div class="form-body">


                                    <div class="form-group">
                                        <label class="control-label col-md-3">وقت وتاريخ </label>
                                        <div class="col-md-6">
                                            <div class="input-group date form_datetime" data-date=""
                                                 data-date-format="dd/mm/yyyy hh:mm:ss">
                                                <input type="text" name="reminder_date" id="reminder_date" readonly
                                                       class="form-control" dir="ltr" disabled>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">تفصيل</label>
                                        <div class="col-md-4">
                                            <div class="input-icon">
                                                <i class="icon-book-open"></i>
                                                <textarea class="form-control" name="reminder_text" id="reminder_text"
                                                          rows="3" disabled></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">ملاحظات</label>
                                        <div class="col-md-4">
                                            <div class="input-icon">
                                                <i class="icon-book-open"></i>
                                                <textarea class="form-control" name="comments" id="comments"
                                                          rows="3" disabled></textarea>
                                            </div>
                                        </div>
                                    </div>


                                </div>


                                {{-- </form>--}}
                                {{Form::close()}}

                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn dark btn-outline" data-dismiss="modal">اغلاق
                    </button>

                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- END CONTENT BODY -->
    @push('css')
        <link href="{{url('')}}/assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.css"
              rel="stylesheet" type="text/css"/>
        <link href="{{url('')}}/assets/global/plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet"
              type="text/css"/>

    @endpush
    @push('js')
        <script src="{{url('')}}/assets/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amcharts/amcharts.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amcharts/serial.js" type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amcharts/pie.js" type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amcharts/radar.js" type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amcharts/themes/light.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amcharts/themes/patterns.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amcharts/themes/chalk.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/ammap/ammap.js" type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/ammap/maps/js/worldLow.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/amcharts/amstockcharts/amstock.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/global/plugins/fullcalendar/fullcalendar.min.js"
                type="text/javascript"></script>
        <script src="{{url('')}}/assets/pages/scripts/dashboard.js" type="text/javascript"></script>
        <script>

            function show_Reminder(id) {

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "POST",
                    url: '{{url('reminder-source')}}',
                    data: {id: id},

                    success: function (data) {
                        $('#file_no').html('');
                        $('#reminder_date').val('');
                        $('#reminder_text').html('');
                        $('#comments').html('');
                        if (data.data.file_no != '') {
                            $('#fileDv').css('display', 'block');
                            $('#file_no').html(data.data.file_no);
                        }
                        else {
                            $('#fileDv').css('display', 'none');
                            $('#file_no').html('');
                        }


                        $('#reminder_date').val(data.data.reminder_date);
                        $('#reminder_text').html(data.data.reminder_text);
                        $('#comments').html(data.data.comments);

                    }

                    ,
                    error: function (err) {

                        console.log(err);
                    }

                });
            }

            function show_task(task, date) {
                $('#task_desc').html('');
                $('#task_date').val('')
                $('#task_desc').html(task);
                $('#task_date').val(date)
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "POST",
                url: '{{url('home/lawsuitBar')}}',
                data: {},

                success:

                    function (data) {
                        //alert(data.data[0].type_name);
                        creat_bar_chart(data.data);


                    }

                ,
                error: function (err) {

                    console.log(err);
                }

            })

            function creat_bar_chart(data) {

                var chart = AmCharts.makeChart("dashboard_amchart_3", {
                    "type": "serial",
                    "theme": "light",
                    "pathToImages": App.getGlobalPluginsPath() + "amcharts/amcharts/images/",
                    "autoMargins": true,
                    /*"marginLeft": 30,
                    "marginRight": 8,
                    "marginTop": 10,
                    "marginBottom": 30,*/

                    /*"legend": { //======================== CHECK the legend did NOT APPEAR?????
                      "generateFromData": true //custom property for the plugin
                    },*/
                    "fontFamily": 'Open Sans',
                    "color": '#888',

                    "dataProvider": data, /*[{
                "year": 2009,
                "income": 23.5,
                //"expenses": 18.1
            }, {
                "year": 2010,
                "income": 26.2,
                //"expenses": 22.8
            }, {
                "year": 2011,
                "income": 30.1,
                //"expenses": 23.9
            }, {
                "year": 2012,
                "income": 29.5,
                //"expenses": 25.1
            }, {
                "year": 2013,
                "income": 30.6,
                //"expenses": 27.2,
                //"dashLengthLine": 5
            }, {
                "year": 2014,
                "income": 34.1,
                //"expenses": 29.9,
                //"dashLengthColumn": 5,
                //"alpha": 0.2,
                //"additional": "(projection)"
            }],*/
                    "valueAxes": [{
                        "axisAlpha": 0,
                        "position": "left",
                        'integersOnly': true,
                        "gridColor": "#FFFFFF",
                        "gridAlpha": 0.2,
                        "dashLength": 0,
                        "title": "عدد القضايا",
                        "autoGridCount": false,
                        "gridCount": 5,

                    }],
                    "startDuration": 1,
                    "graphs": [{
                        "alphaField": "alpha",
                        "balloonText": "<span style='font-size:13px;'> [[category]]: <b>[[value]]</b> [[additional]]</span>",
                        "dashLengthField": "dashLengthColumn",
                        "fillAlphas": 1,
                        "title": "النوع",
                        "type": "column",
                        "valueField": "COUNT"	//Name in json
                    }, {
                        "balloonText": "<span style='font-size:13px;'>[[title]] in [[category]]:<b>[[value]]</b> [[additional]]</span>",
                        "bullet": "round",
                        "dashLengthField": "dashLengthLine",
                        "lineThickness": 3,
                        "bulletSize": 7,
                        "bulletBorderAlpha": 1,
                        "bulletColor": "#FFFFFF",
                        "useLineColorForBulletBorder": true,
                        "bulletBorderThickness": 3,
                        "fillAlphas": 0,
                        "lineAlpha": 1,
                        "title": "Expenses",
                        "valueField": "expenses"
                    }],
                    "categoryField": "type_name",	//Name in json
                    "categoryAxis": {
                        "gridPosition": "start",
                        "axisAlpha": 0,
                        "tickLength": 0,
                        "labelRotation": 45		// Label Rotation
                    },
                    "export": {
                        "enabled": true
                    }
                });

                $('#dvChart').closest('.portlet').find('.fullscreen').click(function () {
                    chart.invalidateSize();
                });
            }

            $(document).ready(function () {
                $(".applyBtn").click(function () {

//alert($('[name="daterangepicker_start"]').val());
                    var start_date = $('[name="daterangepicker_start"]').val()
                    var end_date = $('[name="daterangepicker_end"]').val()
                    //   alert('start_date : ' + start_date + ' end_date : ' + end_date);
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    $.ajax({
                        type: "POST",
                        url: '{{url('home/dashboard')}}',
                        data: {start_date: start_date, end_date: end_date},

                        success:

                            function (data) {
                                // alert(data.data.pen_files);
                                //     creat_bar_chart(data.data);
                                $('#open_files').html(data.data.pen_files);
                                $('#session_files').html(data.data.session_files);
                                $('#closed_files').html(data.data.closed_files);
                                $('#result1').html(data.data.result1);
                                $('#result2').html(data.data.result2);
                                $('#result3').html(data.data.result3);
                                //    alert(data.lawsuitBar);
                                creat_bar_chart(data.lawsuitBar);
                            }

                        ,
                        error: function (err) {

                            console.log(err);
                        }

                    })
                });
            });

            function show_lawysuit(id) {

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "POST",
                    url: '{{url('set-id')}}',
                    data: {id: id},

                    success: function (data) {

                        window.location.href = '{{url('/')}}/show-lawsuit';
                    }

                    ,
                    error: function (err) {

                        console.log(err);
                    }

                });
            }

            function update_status(status, id) {
                // alert('status :'+status+' id: '+id)
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "POST",
                    url: '{{url('home/update-task-status')}}',
                    data: {id: id, status: status},

                    success:

                        function (data) {
                            // alert(data.html);
                            $('#task_td').html('');
                            $('#task_td').html(data.html);
                        }

                    ,
                    error: function (err) {

                        console.log(err);
                    }

                });
            }
        </script>
    @endpush

@stop
