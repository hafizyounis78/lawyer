@extends('admin.layout.index')
@section('content')
    <meta name="csrf-token" content="{{ csrf_token()}}">
    <div class="page-content">
        <h1 class="page-title"> {{$title}}
            <small>{{$page_title}}</small>
        </h1>
        <div class="page-bar">
            @include('admin.layout.breadcrumb')

        </div>

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="col-md-6">
                            <div class="caption font-dark">
                                <i class="icon-settings font-dark"></i>
                                <span class="caption-subject bold uppercase">{{$page_title}}</span>
                            </div>
                        </div>
                        <div class="col-md-6">
                        <ul class="nav nav-pills">
                            <li class="">
                                <a href="javascript:;"> القضايا المفتوحة
                                    <span class="badge badge-primary "> {{$open_files}} </span>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:;"> جلسات
                                    <span class="badge badge-warning"> {{$session_files}} </span></a>
                            </li>
                            <li>
                                <a href="javascript:;"> القضايا المغلقة
                                    <span class="badge badge-danger">  {{$closed_files}} </span>
                                </a>
                            </li>
                        </ul>
                        </div>
                    </div>


                    {{--       <div class="row list-separated profile-stat">
                               <div class="col-md-4 col-sm-4 col-xs-6">
                                   <div class="uppercase profile-stat-title"> {{$result1}} </div>
                                   <div class="uppercase profile-stat-text label label-success"> ايجابي </div>
                               </div>
                               <div class="col-md-4 col-sm-4 col-xs-6">
                                   <div class="uppercase profile-stat-title"> {{$result2}} </div>
                                   <h3><span class="label label-danger"> سلبي </span></h3>
                               </div>
                               <div class="col-md-4 col-sm-4 col-xs-6">
                                   <div class="uppercase profile-stat-title"> {{$result3}} </div>
                                   <div class="uppercase profile-stat-text"> صلح </div>
                               </div>
                           </div>--}}
                    <div class="portlet-body">
                        <div class="table-toolbar">
                            <div class="row">
                                @if (in_array(9, auth()->user()->user_per))
                                    <div class="col-md-6">
                                        <div class="btn-group">
                                            <a href="{{url('/lawsuit/create')}}" class="btn sbold green"> اضافة قضية
                                                جديدة
                                                <i class="fa fa-plus"></i>
                                            </a>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>

                        <table class="table table-striped table-bordered table-hover " id="lawsuit_tbl">
                            <thead>
                            <tr>
                                <th width="5%"> #</th>
                                <th width="10%"> رقم الملف</th>
                                {{--  <th width="10%">نوع القضية</th>--}}
                                <th width="10%">نوع الدعوة</th>
                                <th width="10%">الموكل</th>
                                <th width="10%">الخصم</th>
                                {{-- <th> جوال </th>--}}
                                <th width="10%"> جهة الدعوى</th>
                                <th width="10%">تاريخ فتح الملف</th>
                                <th width="10%"> حالة القضية</th>
                                <th width="15%">تحكم</th>
                            </tr>
                            </thead>
                        </table>

                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
    @push('js')
        <script>
            $(document).ready(function () {
                $('#lawsuit_tbl').dataTable({

                    'processing': true,
                    'serverSide': true,

                    'ajax': '{{url('lawsuit-data')}}',
                    'columns': [
                        {data: 'num', name: 'num'},
                        {data: 'file_no', name: 'file_no'},
                        {data: 'lawsuitColor', name: 'lawsuitColor'},
                        /*     {data: 'suit_type', name: 'suit_type'},*/
                        {data: 'agent_name', name: 'agent_name'},//الموكل
                        {data: 'respondent_name', name: 'respondent_name'},//المدعى عليه
                        /*                        {data: 'lawsuit_value', name: 'lawsuit_value'},//جوال*/
                        /* {data: 'image', name: 'image'},*/
                        {data: 'judge', name: 'judge'},
                        {data: 'open_date', name: 'open_date'},
                        {data: 'file_status_desc', name: 'file_status_desc'},

                        {data: 'action', name: 'action'},


                    ],
                    "language": {
                        "aria": {
                            "sortAscending": ": activate to sort column ascending",
                            "sortDescending": ": activate to sort column descending"
                        },
                        "emptyTable": "لايوجد بيانات في الجدول للعرض",
                        "info": "عرض _START_ الى  _END_ من _TOTAL_ سجلات",
                        "infoEmpty": "No records found",
                        "infoFiltered": "(filtered1 from _MAX_ total records)",
                        "lengthMenu": "عرض _MENU_",
                        "search": "بحث:",
                        "zeroRecords": "No matching records found",
                        "paginate": {
                            "previous": "Prev",
                            "next": "Next",
                            "last": "Last",
                            "first": "First"
                        }
                    },
                })
                /* $('#lawsuit_tbl').dataTable({

                     'processing': true,
                     'serverSide': true,

                     'ajax': '{{url('lawsuit-data')}}',
                    'columns': [
                        {data: 'num', name: 'num'},
                        {data: 'file_no', name: 'file_no'},
                        {data: 'lawsuitColor', name: 'lawsuitColor'},
                        {data: 'suit_type', name: 'suit_type'},
                        {
                            data: 'suit_type', name: 'suit_type',

                            render: function (data, type, full, meta) {
                                return ' عبدالكريم جبارة';

                            }
                        },//الموكل
                        {
                            data: 'suit_type', name: 'suit_type',


                            render: function (data, type, full, meta) {
                                return ' محمد مكي ';

                            }
                        },//المدعى عليه
                        /!*                        {data: 'lawsuit_value', name: 'lawsuit_value'},//جوال*!/
                        /!* {data: 'image', name: 'image'},*!/
                        {data: 'judge', name: 'judge'},
                        {data: 'open_date', name: 'open_date'},
                        {data: 'file_status.desc', name: 'file_status.desc'},

                        {data: 'action', name: 'action'},


                    ],
                    "language": {
                        "aria": {
                            "sortAscending": ": activate to sort column ascending",
                            "sortDescending": ": activate to sort column descending"
                        },
                        "emptyTable": "لايوجد بيانات في الجدول للعرض",
                        "info": "عرض _START_ الى  _END_ من _TOTAL_ سجلات",
                        "infoEmpty": "No records found",
                        "infoFiltered": "(filtered1 from _MAX_ total records)",
                        "lengthMenu": "عرض _MENU_",
                        "search": "بحث:",
                        "zeroRecords": "No matching records found",
                        "paginate": {
                            "previous": "Prev",
                            "next": "Next",
                            "last": "Last",
                            "first": "First"
                        }
                    },
                })*/
            })

            function saveSession(id, url) {
                //   alert(url);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: '{{url('set-id')}}',

                    data: {id: id, url: url},
                    error: function (xhr, status, error) {

                    },
                    beforeSend: function () {
                    },
                    complete: function () {
                    },
                    success: function (data) {

                        window.location.href = '{{url('/')}}/' + url;
                    }
                });//END $.ajax
            }
        </script>
    @endpush
@stop
