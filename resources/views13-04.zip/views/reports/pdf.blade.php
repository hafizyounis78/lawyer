<!doctype html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <title>Document</title>

    <link rel="stylesheet" media="screen" href="{{url('assets/xb-riyaz.css')}}" type="text/css"/>
    {{--<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />--}}
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
<style>
    /*@import url(http://fonts.googleapis.com/earlyaccess/droidarabickufi.css);*/
    body, th, td {
        font-family: 'xbriyaz', sans-serif;

    }

    th, td {
        font-size: 13;

    }
    td {
        font-size: 12;

    }
    .table-title
    {
        border: 0;
    }

    .table,th, td  {

        border: 1px solid grey;

    }
    .table {

        border-collapse: collapse;

    }
    th {
        text-align: right !important;
        /*   width: 20% !important;*/
    }

    hr {
        display: block;
        height: 1px;
        border: 0;
        border-top: 1px solid #ccc;
        margin: 1em 0;
        padding: 0;
    }
    }
</style>
</head>
<body>
<div class="page-content">
    <meta name="csrf-token" content="{{ csrf_token()}}">
    <h1 class="page-title"> تقرير الملفات القضائية

    </h1>

    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet light bordered">
                <div class="portlet-title">


                </div>
                <div class="portlet-body">
                    <div class="table-toolbar">
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-2">
                        </div>

                    </div>
                    <table border="1" class="table table-striped table-bordered table-hover table-checkable order-column"
                           id="report_tbl">
                        <thead>
                        <tr>
                            <th> #</th>
                            <th> المحكمة</th>
                            <th>الموكل</th>
                            <th> الخصم</th>
                            <th> نوع الدعوى</th>
                            <th> قيمة الدعوى</th>
                            <th> رقم الدعوة</th>
                            <th>تاريخ الإجراء</th>
                            <th>تاريخ الجلسة</th>
                            <th>إجراءات الدعوى</th>
                        </tr>
                        </thead>
                        <tbody>
                        {!! $html !!}
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>
</div>
</body>
</html>
